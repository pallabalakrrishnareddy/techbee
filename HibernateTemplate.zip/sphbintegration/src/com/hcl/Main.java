package com.hcl;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {
	public static void main(String[] args) {
		 ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
		EmployeeDao dao=(EmployeeDao)context.getBean("d");
		
		Employee e=new Employee();
		e.setId(147);
		e.setName("kumar");
		e.setSalary(70000);
		
		dao.saveEmployee(e);
		//dao.updateEmployee(e);
	}
	}
